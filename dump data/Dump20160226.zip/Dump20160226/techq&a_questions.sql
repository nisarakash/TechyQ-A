-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: techq&a
-- ------------------------------------------------------
-- Server version	5.7.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `qid` int(11) NOT NULL,
  `qtitle` varchar(150) DEFAULT NULL,
  `qquestion` varchar(5000) NOT NULL,
  `timestamp` datetime NOT NULL,
  `username` varchar(45) NOT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'Spring RowMapper returns ArrayList for one result','I\'m using Spring Boot to build REST service which connects to Oracle DB. I\'m allso using Spring JDBC.I have a following code:jdbcCall.declareParameters(new SqlParameter(\"P_IN\", OracleTypes.VARCHAR));jdbcCall.declareParameters(new SqlOutParameter(\"P_OUT\", OracleTypes.CURSOR, new ClientMapper()));MapSqlParameterSource in = new MapSqlParameterSource().addValue(\"P_IN\", \"123\");Map out = jdbcCall.execute(in);Client client = (Client) out.get(\"P_OUT\");Procedure returns just one result, but when I execute the code I get the following errror:java.lang.ClassCastException: java.util.ArrayList cannot be cast to com.test.model.ClientIn a debug mode I can see that out.get(\"P_OUT\")returns ArrayList with 10 objects, First one is my Client object and others are set to null.I\'m confused, what am I doing wrong and hove to fix it?','2016-02-26 20:42:10','dplesa'),(2,'Role/Purpose of ContextLoaderListener in spring?','I am learning spring which is being used in my project.I found the ContextLoaderListener entry in my web.xml . But could not figure out how exactly it helps the developer? In official doc of ContextLoaderListener it says it is to start WebApplicationContext . Regarding WebApplicationContext , api says Interface to provide configuration for a web application . But i am not able to understand what i am achieving with ContextLoaderListener which internally init the WebApplicationContext ?','2016-02-25 18:40:23','Sangdol'),(3,'Java program controlled by Console?','I want to know if its possible to control my game with arrow keys. It is basic version of \"2048\" game as a console output. My idea:if(arrowKeyRight is pressed){ moveNumbersToRight}Is it possible for my program to read the arrow keys as an output?','2015-01-19 22:20:14','Martin'),(4,'What is a Null Pointer Exception, and how do I fix it?','What are Null Pointer Exceptions (java.lang.NullPointerException) and what causes them?What methods/tools can be used to determine the cause so that you stop the exception from causing the program to terminate prematurely?','2008-08-20 13:18:43','Ziggy'),(5,'Is Java “pass-by-reference” or “pass-by-value”?','I always thought Java was pass-by-reference; however I\'ve seen a couple of blog posts (for example, this blog) that claim it\'s not. I don\'t think I understand the distinction they\'re making.','2011-06-10 16:18:17','user4315'),(6,'Unfortunately MyApp has stopped. How can I solve this?','I am developing an application, and everytime I run it, I get the message: Unfortunately, MyApp has stopped. What can I do to solve this?','2015-08-15 08:13:34','nhaarman'),(7,'How to add JTable in JPanel','I want to add JTable into JPanel whose layout is null.  JPanel contains other components. I have to add JTable at proper position.','2014-09-02 10:36:29','Sagar'),(8,'Providing white space in a Swing GUI','A GUI with no white space appears \'crowded\'. How can I provide white space without resorting to explicitly setting the position or size of components?','2013-07-26 06:50:13','andrew'),(9,'How do I write a correct micro-benchmark in Java?','How do you write (and run) a correct micro-benchmark in Java?I\'m looking here for code samples and comments illustrating various things to think about.Example: Should the benchmark measure time/iteration or iterations/time, and why?','2009-02-02 17:39:05','Tshepang'),(10,'What issues should be considered when overriding equals and hashCode in Java?','What issues / pitfalls must be considered when overriding equals and hashCode?','2014-08-11 19:02:54','george'),(11,'What is a raw type and why shouldn\'t we use it?','What are raw types in Java, and why do I often hear that they shouldn\'t be used in new code? What is the alternative if we can\'t use raw types, and how is it better?','2010-05-05 02:48:39','polygenelubricants'),(12,'What issues should be considered when overriding equals and hashCode in Java?','What issues / pitfalls must be considered when overriding equals and hashCode?','2008-08-26 08:50:23','george'),(13,'Syntax error on print with Python 3','Why do I receive a syntax error when printing a string in Python 3?>>> print \"hello World\" File \"<stdin>\", line 1 print \"hello World\" SyntaxError: invalid syntax','2014-09-12 07:20:46','duncan'),(14,'How do I do variable variables in Python?','How do I accomplish variable variables in Python?Here is an elaborative manual entry, for instance: Variable variables I hear this is a bad idea in general though, and it is a security hole in PHP. Is that true?','2012-07-21 18:32:58','pyornide'),(15,'Python, Unicode, and the Windows console','When I try to print a Unicode string in a Windows console, I get a UnicodeEncodeError: \'charmap\' codec can\'t encode character .... error. I assume this is because the Windows console does not accept Unicode-only characters. What\'s the best way around this? Is there any way I can make Python automatically print a ? instead of failing in this situation?','2016-01-06 11:07:07','alvas'),(16,'Python read a single character from the user','Is there a way of reading one single character from the user input? For instance, they press one key at the terminal and it is returned (sort of like getch()). I know there\'s a function in Windows for it, but I\'d like something that is cross-platform.','2015-05-10 14:56:09','maskedman'),(17,'Static class variables in Python','Is it possible to have static class variables or methods in python? What syntax is required to do this?','2014-09-10 12:10:29','lpapp'),(18,'What should main() return in C and C++?','What is the correct (most efficient) way to define the main() function in C and C++ — int main() or void main() — and why? If int main() then return 1 or return 0?','2015-11-10 19:23:01','joel'),(19,'How do I use extern to share variables between source files in C?','I know that global variables in C sometimes have the extern keyword. What is an extern variable? What is the declaration like? What is its scope?This is related to sharing variables across source files, but how does that work precisely? Where do I use extern?','2014-03-28 15:46:00','shilpa'),(20,'With C arrays, why is it the case that a[5] == 5[a]?','As Joel points out in Stack Overflow podcast #34, in C Programming Language (aka: K & R), there is mention of this property of arrays in C: a[5] == 5[a]Joel says that it\'s because of pointer arithmetic but I still don\'t understand. Why does a[5] == 5[a]?','2014-12-07 06:01:44','noam'),(21,'What is the LD_PRELOAD trick?','I came across a reference to it recently on proggit and (as of now) it is not explained.I suspect this might be it, but I don\'t know for sure.','2014-04-15 21:11:16','ash'),(22,'Pointer Arithmetic','Does anyone have any good articles or explanations (blogs, examples) for pointer arithmetic? Figure the audience is a bunch of Java programmers learning C and C++.','2016-02-25 09:34:10','leora'),(23,'How do you reverse a string in place in C or C++?','How do you reverse a string in C or C++ without requiring a separate buffer to hold the reversed string?','2012-11-24 15:35:27','uvote'),(24,'What is a NullReferenceException and how do I fix it?','I have some code and when it executes, it throws a NullReferenceException, saying:Object reference not set to an instance of an object. What does this mean, and what can I do about it?','2015-05-01 02:20:23','saunder'),(25,'Create Excel (.XLS and .XLSX) file from C#','How can I create an Excel Spreadsheet with C# without requiring Excel to be installed on the machine that\'s running the code?','2015-10-09 07:04:51','mistrmark');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-26 17:18:48
